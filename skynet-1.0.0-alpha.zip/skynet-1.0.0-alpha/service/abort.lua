local skynet = require "skynet"

skynet.abort()
